import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const WaterHisabApp());

class WaterHisabApp extends StatelessWidget {
  const WaterHisabApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Water Hisab',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const HomePage(),
    );
  }
}

class Customer {
  String id, name, phone;
  Customer({required this.id, required this.name, this.phone = ''});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'phone':phone};
  factory Customer.fromJson(Map<String,dynamic> j)=>Customer(id:j['id'],name:j['name'],phone:j['phone']??'');
}

class Entry {
  String customerId, date;
  int normal, chilled, payment, emptyReturned;
  Entry({required this.customerId, required this.date, this.normal=0,this.chilled=0,this.payment=0,this.emptyReturned=0});
  Map<String,dynamic> toJson()=>{'customerId':customerId,'date':date,'normal':normal,'chilled':chilled,'payment':payment,'emptyReturned':emptyReturned};
  factory Entry.fromJson(Map<String,dynamic> j)=>Entry(customerId:j['customerId'],date:j['date'],normal:j['normal']??0,chilled:j['chilled']??0,payment:j['payment']??0,emptyReturned:j['emptyReturned']??0);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Customer> customers=[];
  List<Entry> entries=[];
  double normalRate=20, chilledRate=25;
  int tab=0;

  @override void initState(){super.initState(); load();}

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    setState((){
      customers=(jsonDecode(p.getString('customers')??'[]') as List).map((x)=>Customer.fromJson(x)).toList();
      entries=(jsonDecode(p.getString('entries')??'[]') as List).map((x)=>Entry.fromJson(x)).toList();
      normalRate=p.getDouble('normalRate')??20;
      chilledRate=p.getDouble('chilledRate')??25;
    });
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('customers',jsonEncode(customers.map((x)=>x.toJson()).toList()));
    await p.setString('entries',jsonEncode(entries.map((x)=>x.toJson()).toList()));
    await p.setDouble('normalRate',normalRate); await p.setDouble('chilledRate',chilledRate);
  }

  Customer? customer(String id){for(final c in customers){if(c.id==id)return c;}return null;}
  List<Entry> monthEntries(String id){final now=DateTime.now(); return entries.where((e){final d=DateTime.tryParse(e.date);return e.customerId==id&&d!=null&&d.year==now.year&&d.month==now.month;}).toList();}
  double bill(String id){return monthEntries(id).fold(0,(s,e)=>s+e.normal*normalRate+e.chilled*chilledRate);}
  int jars(String id){return monthEntries(id).fold(0,(s,e)=>s+e.normal+e.chilled);}
  int paid(String id){return monthEntries(id).fold(0,(s,e)=>s+e.payment);}
  int emptyOut(String id){return entries.where((e)=>e.customerId==id).fold(0,(s,e)=>s+e.normal+e.chilled);}
  int emptyReturned(String id){return entries.where((e)=>e.customerId==id).fold(0,(s,e)=>s+e.emptyReturned);}
  int emptyBalance(String id)=>emptyOut(id)-emptyReturned(id);

  Future<void> addCustomer() async {
    final n=TextEditingController(), ph=TextEditingController();
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Add Customer'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,decoration:const InputDecoration(labelText:'Customer name')),
      TextField(controller:ph,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'WhatsApp number')),
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){if(n.text.trim().isNotEmpty){customers.add(Customer(id:DateTime.now().microsecondsSinceEpoch.toString(),name:n.text.trim(),phone:ph.text.trim()));save();setState((){});Navigator.pop(context);}},child:const Text('Save'))]));
  }

  Future<void> addEntry() async {
    if(customers.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('पहले Customer जोड़ें')));return;}
    String cid=customers.first.id; final no=TextEditingController(text:'0'), ch=TextEditingController(text:'0'), pay=TextEditingController(text:'0'), ret=TextEditingController(text:'0');
    await showDialog(context:context,builder:(_)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('आज की Entry'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      DropdownButtonFormField<String>(value:cid,items:customers.map((c)=>DropdownMenuItem(value:c.id,child:Text(c.name))).toList(),onChanged:(v){if(v!=null)setD(()=>cid=v);},decoration:const InputDecoration(labelText:'Customer')),
      TextField(controller:no,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Normal Jar')),
      TextField(controller:ch,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Chilled Jar')),
      TextField(controller:pay,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Payment Received ₹')),
      TextField(controller:ret,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Empty Jar Returned')),
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){entries.add(Entry(customerId:cid,date:DateTime.now().toIso8601String(),normal:int.tryParse(no.text)??0,chilled:int.tryParse(ch.text)??0,payment:int.tryParse(pay.text)??0,emptyReturned:int.tryParse(ret.text)??0));save();setState((){});Navigator.pop(context);},child:const Text('Save'))])));
  }

  Future<void> rates() async {
    final n=TextEditingController(text:normalRate.toStringAsFixed(0)), c=TextEditingController(text:chilledRate.toStringAsFixed(0));
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Jar Rates'),content:Column(mainAxisSize:MainAxisSize.min,children:[
      TextField(controller:n,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Normal ₹ / Jar')),
      TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Chilled ₹ / Jar')),
    ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){normalRate=double.tryParse(n.text)??normalRate;chilledRate=double.tryParse(c.text)??chilledRate;save();setState((){});Navigator.pop(context);},child:const Text('Save'))]));
  }

  Future<void> whatsapp(Customer c) async {
    final msg='Water Hisab - ${DateTime.now().month}/${DateTime.now().year}\nकुल Jar: ${jars(c.id)}\nकुल Bill: ₹${bill(c.id).toStringAsFixed(0)}\nजमा: ₹${paid(c.id)}\nबाकी: ₹${(bill(c.id)-paid(c.id)).toStringAsFixed(0)}\nखाली Jar ग्राहक के पास: ${emptyBalance(c.id)}';
    final phone=c.phone.replaceAll(RegExp(r'[^0-9]'),'');
    final uri=Uri.parse('https://wa.me/${phone.isEmpty ? "" : phone}?text=${Uri.encodeComponent(msg)}');
    if(await canLaunchUrl(uri)) await launchUrl(uri,mode:LaunchMode.externalApplication);
  }

  @override Widget build(BuildContext context){
    final pages=[dashboard(),customersPage(),monthlyPage()];
    return Scaffold(appBar:AppBar(title:const Text('💧 Water Hisab'),actions:[IconButton(onPressed:rates,icon:const Icon(Icons.settings))]),body:pages[tab],
      floatingActionButton:tab==0?FloatingActionButton.extended(onPressed:addEntry,icon:const Icon(Icons.add),label:const Text('आज की Entry')):tab==1?FloatingActionButton.extended(onPressed:addCustomer,icon:const Icon(Icons.person_add),label:const Text('Customer')):null,
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people),label:'Customers'),
        NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'Monthly'),
      ]));
  }

  Widget dashboard()=>ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('आज का काम',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('Customer चुनें → Jar डालें → Save करें'),const SizedBox(height:12),Text('Customers: ${customers.length}'),Text('इस महीने कुल Jar: ${entries.where((e){final d=DateTime.tryParse(e.date);final n=DateTime.now();return d!=null&&d.year==n.year&&d.month==n.month;}).fold(0,(s,e)=>s+e.normal+e.chilled)}')]))) ,
    const SizedBox(height:12),...customers.map((c)=>Card(child:ListTile(title:Text(c.name),subtitle:Text('Jar: ${jars(c.id)}  |  Bill: ₹${bill(c.id).toStringAsFixed(0)}  |  बाकी: ₹${(bill(c.id)-paid(c.id)).toStringAsFixed(0)}'),trailing:IconButton(icon:const Icon(Icons.chat),onPressed:()=>whatsapp(c)))))
  ]);

  Widget customersPage()=>ListView(padding:const EdgeInsets.all(12),children:customers.map((c)=>Card(child:ListTile(title:Text(c.name),subtitle:Text(c.phone.isEmpty?'WhatsApp number नहीं है':c.phone),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>customers.removeWhere((x)=>x.id==c.id));save();}))).toList());

  Widget monthlyPage()=>ListView(padding:const EdgeInsets.all(12),children:[const Padding(padding:EdgeInsets.all(8),child:Text('इस महीने का हिसाब',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),...customers.map((c)=>Card(child:ListTile(title:Text(c.name),subtitle:Text('Normal/Chilled Jar सहित कुल: ${jars(c.id)}\nBill ₹${bill(c.id).toStringAsFixed(0)} | जमा ₹${paid(c.id)} | बाकी ₹${(bill(c.id)-paid(c.id)).toStringAsFixed(0)}\nखाली Jar बाकी: ${emptyBalance(c.id)}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.send),onPressed:()=>whatsapp(c))))]);
}
